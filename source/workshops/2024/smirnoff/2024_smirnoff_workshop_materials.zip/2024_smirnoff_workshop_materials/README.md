# SMIRNOFF workshop

Create the environment:

```shell
micromamba create -n smirnoff-workshop -f env.yml
```

Run Jupyter Lab in the new environment:

```shell
micromamba run -n smirnoff-workshop jupyter-lab
```
