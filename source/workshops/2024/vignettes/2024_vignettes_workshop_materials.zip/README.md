# 2024 Vignettes Workshop

Create the conda environment:

```shell
mamba create -f examples_env.yml -n vignettes-workshop
```

Run Jupyter Lab from the environment:

```shell
mamba run -n vignettes-workshop jupyter lab
```
